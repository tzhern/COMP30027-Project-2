# Welcome to my project
## Instruction
1. open and run project-2.ipynb file
2. after running the file, you can find the prediction under the folder "output"

## Thank you